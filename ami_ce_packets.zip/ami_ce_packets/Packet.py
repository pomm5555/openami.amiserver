from xml.dom.minidom import Document


class Packet:

    def __init__(self, fr, to, string=""):

        # Create the minidom document
        self.doc = Document()

        # Create the <wml> base element
        packet = self.doc.createElement("packet")
        packet.setAttribute("from", fr)
        packet.setAttribute("to", to)
        self.doc.appendChild(packet)

        # Give the <p> elemenet some text
        text = self.doc.createTextNode(string)
        packet.appendChild(text)


    def __str__(self):
        return self.doc.toprettyxml(indent="  ")