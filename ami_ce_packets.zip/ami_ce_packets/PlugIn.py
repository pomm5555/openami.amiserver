# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__="markus"
__date__ ="$Aug 16, 2009 3:48:26 PM$"


from Ami_tree import Container


class PlugIn:
    def getTree(self):
        pass

