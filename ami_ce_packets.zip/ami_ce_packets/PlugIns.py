# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__="markus"
__date__ ="$Aug 20, 2009 12:22:08 AM$"
from AmiTree import Container
import os

class PlugIns:

    def __init__(self, token, information, folder):

        pluginsFolder = folder


        # create root container
        self.root = Container(token, information)

        #print os.path.walk("./"+pluginsFolder, None, "None")



        # Load plugins from folder
        pluginFiles =  os.listdir("./"+pluginsFolder)
        i=0
        for elem in pluginFiles:
            if elem[-3:].__eq__(".py") and not (elem[:1].__eq__("_")):
                print "loading: "+ elem
                exec("from "+pluginsFolder+"."+elem[:-3]+" import "+elem[:-3])
                exec("system = Finder(\""+elem[:-3]+"\")")
                exec("self.root.addChild(\""+elem[:-3]+"\", system.getTree())")
            if os.path.isdir("./"+pluginsFolder+"/"+elem):
                print "path: "+"./"+pluginsFolder+"/"+elem
                self.root.addContainer(elem)

        # LOAD ITUNES PLUGIN MANUALLY
        # create library object, first parameter,
        # Add ITunes Plugin to tree
        # self.root.addChild("iTunes", ITunes("iTunes").getTree())

    def getTree(self):
        return self.root
    