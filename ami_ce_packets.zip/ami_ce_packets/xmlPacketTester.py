from Packet import Packet

if __name__ == "__main__":
    print "Hello World";


    p = Packet("slkdfj", "sldkfjlsd", "lskdfdf")
    print p


    print p.__str__().split("\n")[0]